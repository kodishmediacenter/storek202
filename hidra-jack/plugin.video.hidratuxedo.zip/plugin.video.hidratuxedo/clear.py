import xbmcvfs
import os
import shutil

def limpar():
    for a in ['special://home/addons/plugin.video.cineplus']:
        existe = xbmcvfs.translatePath(a)
        if os.path.exists(existe)==True:
            shutil.rmtree(existe)
   
