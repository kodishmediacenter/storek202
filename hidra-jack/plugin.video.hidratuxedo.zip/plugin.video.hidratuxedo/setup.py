from pathlib import Path
import xbmcgui
import xbmcvfs
import os 

def main():
	folder  = os.path.join(xbmcvfs.translatePath("special://home/addons/teste"))
	dialog = xbmcgui.Dialog()

	# Especificar o nome da pasta que deseja criar
	nome_pasta = folder

	# Criar um objeto de caminho (path) para a pasta
	pasta = Path(nome_pasta)

	# Verificar se a pasta já existe antes de criar
	if not pasta.exists():
	    pasta.mkdir()
	    print("Pasta criada com sucesso!")
	else:
	    print("A pasta já existe.")


def main2():

        import shutil,os

        # Especificar o caminho da pasta de origem e destino
        pasta_origem = os.path.join(xbmcvfs.translatePath("special://home/addons/plugin.video.hidratuxedo/resources/scripts/plugin.video.pokemontv"))
        pasta_destino = os.path.join(xbmcvfs.translatePath("special://home/addons/plugin.video.pokemontv"))

        # Copiar a pasta de origem para o destino
        shutil.copytree(pasta_origem, pasta_destino)

        print("Pasta copiada com sucesso!")
