import xbmc
import xbmcgui

def web_browser(urlcn):
        import webbrowser
        if xbmc . getCondVisibility ( 'system.platform.android' ) :
                ost = xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( ''+urlcn+'' ) )
        else:
                ost = webbrowser . open ( ''+urlcn+'' )







def menu():
    dialog = xbmcgui.Dialog()
    player = dialog.select('Grande Conquista: ', ['Canal 1','Canal 2'])

    if player == 0:
            url = "https://multicanais.website/a-grande-conquista-ao-vivo-24-horas-camera-1/"
            web_browser(url)

    if player == 1:
            url = "https://multicanais.website/a-grande-conquista-ao-vivo-24-horas-camera-2/"
            web_browser(url)

